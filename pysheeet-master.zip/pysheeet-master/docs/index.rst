.. python-cheatsheet documentation master file, created by
   sphinx-quickstart on Sun Feb 28 09:26:04 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Python cheatsheet!
=============================================

.. toctree::
   :maxdepth: 2

   notes/python-basic
   notes/python-unicode
   notes/python-generator
   notes/python-rexp
   notes/python-socket
   notes/python-crypto
   notes/python-concurrency
   notes/python-sqlalchemy
   notes/python-asyncio
   notes/python-tests
   notes/python-capi
   notes/python-cstyle
